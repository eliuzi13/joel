Please make sure that your commit messages follow our [convention](http://karma-runner.github.io/latest/dev/git-commit-msg.html)!
