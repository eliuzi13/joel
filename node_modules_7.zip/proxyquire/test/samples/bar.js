function bar () {
  return 'bar';
}

function rab () {
  return 'rab';
}

module.exports = { bar : bar, rab: rab };

