
module.exports = function() {
  var bar = require('./bar');

  return bar();
}
