module.exports = {
  method: function() {
    return false;
  }
}
