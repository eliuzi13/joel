var baz = require('./baz');

module.exports = function() {
  return baz.method();
}
