var bar = require('./bar');

module.exports = function() {
  return bar();
}
