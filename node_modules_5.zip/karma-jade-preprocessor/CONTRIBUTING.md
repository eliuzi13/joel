Please see the [Contributing to Testacular] guide for information on contributing to this project.

[Contributing to Testacular]: https://github.com/testacular/testacular/blob/master/CONTRIBUTING.md
