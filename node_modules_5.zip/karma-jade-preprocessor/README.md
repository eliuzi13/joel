# karma-handlebars-preprocessor

> Preprocessor to compile Handlebars on the fly.

fork from [hanachin/karma-handlebars-preprocessor· GitHub](https://github.com/hanachin/karma-handlebars-preprocessor)

also borrowing from 
fschwiet posted in https://github.com/karma-runner/karma/issues/572

For more information on karma see the [homepage].





[homepage]: http://karma-runner.github.com

