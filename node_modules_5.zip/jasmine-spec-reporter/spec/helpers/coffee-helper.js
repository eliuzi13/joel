require('coffee-script/register');
