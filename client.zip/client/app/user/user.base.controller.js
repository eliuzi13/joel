'use strict';
/**
 * @ngdoc contuserler
 * @name adminApp.baseUserCtrl
 * @description
 * # baseUserCtrl
 * Contuser in the adminApp.
 */
angular.module('adminApp').controller('baseUserCtrl', ['$scope', 'User', '$filter', 'Module','Rol','OauthClient',
    function ($scope, User, $filter, Module,Rol,OauthClient) {
        var _useres;
        $scope.user = new User({permissions: [], clients: [],roles:[]});
        $scope.show = {delete: false, save: true, undo: true};
        $scope.original = angular.copy($scope.user);
        $scope.passwdPatron = /^[0-9a-zA-Z]{6,}$/;
        $scope.canSave = function () {
            return $scope.frmUser.$valid;
        };
        $scope.canRevert = function () {
            return !angular.equals($scope.user, $scope.original);
        };
        $scope.reset = function () {
            $scope.user = angular.copy($scope.original);
            $scope.frmUser.$setPristine();
        };
        Rol.query({paginate: 0}, function (response) {
            $scope.roles = response.data;
        });
         OauthClient.query({paginate: 0}, function (response) {
            $scope.clients = response.data;
        });
        //
        $scope.loadCurrentPermisions = function (permissions) {

            if (_useres === undefined) {
                Module.query({showActions: 1, paginate: '0'}, function (response) {
                    angular.forEach(response.data, function (value) {
                        angular.forEach(value.actions, function (sub) {
                            sub.key = value.name + '.' + sub.name;
                        });
                    });
                    _useres = response.data;
                    setPermisos(permissions);
                });
            } else {
                setPermisos(permissions);
            }

        };
         $scope.$watchCollection('user.roles', function () {
                    $scope.margePermisions();
                });
        $scope.margePermisions = function () {
            var permisos = {};
            angular.forEach($scope.user.roles, function (id) {
                var d = $filter('filter')($scope.roles, {id: id}, function (current, id) {
                    if (current === id) {
                        return true;
                    }
                });
                if (d !== undefined) {
                    var _permisos = angular.fromJson(d[0].permissions);
                    angular.forEach(_permisos, function (value, key) {
                        if (permisos[key] === undefined && parseInt(value) === true) {
                            permisos[key] = null;
                        }
                    });
                }
            });
            var permisosUsuario = $scope.user.permissions;
            angular.forEach(permisosUsuario, function (value, key) {
                permisos[key] = value;
            });
            $scope.loadCurrentPermisions(permisos);
        };
        function setPermisos(permissions) {
            angular.forEach(_useres, function (value) {
                angular.forEach(value.actions, function (sub) {
                    sub.module = undefined;
                });
            });
            angular.forEach(permissions, function (value, key) {
                $filter('filter')(_useres, {actions: key}, function (current, permiso) {
                    if (current.key === permiso) {
                        current.permiso = value;
                        return true;
                    }
                });
            });
            $scope.modules = _useres;
        }
        $scope.changeState2 = function (action) {
            if (action.permiso === undefined ||
                    action.permiso === false) {
                action.permiso = true;
            } else if (action.permiso === true) {
                action.permiso = null;
            } else if (action.permiso === null) {
                action.permiso = false;
            }
            $scope.user.permissions[action.key] = action.permiso;
        };

        $scope.checkAll = function ($index) {
            if ($scope.modules[$index].state === undefined ||
                    $scope.modules[$index].state === -1) {
                $scope.modules[$index].state = 1;
            } else if ($scope.modules[$index].state === 1) {
                $scope.modules[$index].state = 0;
            } else if ($scope.modules[$index].state === 0) {
                $scope.modules[$index].state = -1;
            }
            var len = $scope.modules[$index].actions.length;
            for (var i = len - 1; i >= 0; i--) {
                 if($scope.modules[$index].state === 0){
                    $scope.modules[$index].actions[i].permiso = false;
                    $scope.user.permissions[ $scope.modules[$index].actions[i].key] = false;
                }else{
                    $scope.modules[$index].actions[i].permiso = true;
                    $scope.user.permissions[ $scope.modules[$index].actions[i].key] = true;
                }
                //$scope.modules[$index].actions[i].permiso = $scope.modules[$index].state;
                //$scope.user.permissions[ $scope.modules[$index].actions[i].key] = $scope.modules[$index].state;
            }
        };

        $scope.toggle = function ($index) {
            $scope.modules[$index].show = !$scope.modules[$index].show;
        };

        $scope.toggleClass = function ($index) {
            if ($scope.modules[$index].show === undefined) {
                $scope.modules[$index].show = false;
            }


            return {
                'fa fa-caret-down': $scope.modules[$index].show === true,
                'fa fa-caret-right': $scope.modules[$index].show === false
            };
        };

        $scope.getClass = function ($index) {
            var partial, all, undef, none, ban = false;
            var cant, bann, undeff, total = 0;
            cant = $filter('filter')($scope.modules[$index].actions, {permiso: true}, true).length;
            bann = $filter('filter')($scope.modules[$index].actions, {permiso: false}, true).length;
            undef = $filter('filter')($scope.modules[$index].actions, {permiso: null}, function (current) {
                if (angular.isUndefined(current) === true) {
                    return true;
                }
            }).length;
            total = $scope.modules[$index].actions.length;
            if (cant === total) {
                all = true;
                $scope.modules[$index].state = 1;
            } else if (bann === total) {
                ban = true;
            } else if (undef === total) {
                undeff = true;
            } else if (cant > 0 || bann > 0 || undef > 0) {
                partial = true;
            } else {
                none = true;
            }
            return  {
                'fa fa-circle text-success': all,
                'fa fa-ban text-danger': ban,
                'fa fa-minus-circle text-warning': undeff,
                'fa fa-dot-circle-o text-muted': partial,
                'fa fa-circle-o text-primary': none
            };
        };


        $scope.getClass2 = function (value) {
            return {
                'fa fa-circle text-success': value === true,
                'fa fa-ban text-danger': value === false,
                'fa fa-minus-circle text-warning': value === undefined,
                'fa fa-circle-o text-primary': value === null
            };

        };
    }]);
