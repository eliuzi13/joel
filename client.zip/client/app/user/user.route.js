'use strict';
angular.module('adminApp')
        .config(function ($stateProvider) {
            $stateProvider.state('users', {
                url: '/users',
                views: {
                    'main@': {
                        templateUrl: 'app/user/user.list.html',
                        controller: 'listUserCtrl'
                    }
                }
            }).state('users.new', {
                url: '/new',
                views: {
                    'main@': {
                        templateUrl: 'app/user/user.form.html',
                        controller: 'creatUserCtrl'
                    }
                }
            }).state('users.edit', {
                url: '/edit/:id',
                views: {
                    'main@': {
                        templateUrl: 'app/user/user.form.html',
                        controller: 'updateUserCtrl'
                    }
                }
            });
        });