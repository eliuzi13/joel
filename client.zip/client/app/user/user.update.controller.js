'use strict';
/**
 * @ngdoc contuserler
 * @name adminApp.updateActioCtrl
 * @description
 * # updateActioCtrl
 * Contuserler in the adminApp.
 */
angular.module('adminApp').controller('updateUserCtrl', ['$scope', '$controller', 'growl', 'Config', '$state', 'User',
    function ($scope, $controller, growl, Config, $state, User) {
        angular.extend(this, $controller('baseUserCtrl', {$scope: $scope}));
        $scope.passwdRequired = false;
        $scope.show = {delete: true, save: true, undo: true};
        $scope.user = User.get({id: $state.params.id}, function (response) {
            $scope.user = response;
            $scope.user.permissions = angular.fromJson($scope.user.permissions);
            if ($scope.user.permissions.length === 0)
            {
                $scope.user.permissions = {};
            }
            $scope.margePermisions();
        });

        $scope.save = function () {
            if ($scope.canSave()) {
                $scope.user.$update(function () {
                    growl.addSuccessMessage(Config.messages.susess, {ttl: Config.successTtl});
                    $state.go('^.');
                });
            }
        };
    }]);
