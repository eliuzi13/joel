'use strict';
/**
 * @ngdoc contuserler
 * @name adminApp.creatUserCtrl
 * @description
 * # creatUserCtrl
 * Contuserler in the adminApp.
 */
angular.module('adminApp').controller('creatUserCtrl', ['$scope', '$controller', 'growl', 'Config', '$state',
    function ($scope, $controller, growl, Config, $state) {
        angular.extend(this, $controller('baseUserCtrl', {$scope: $scope}));
         $scope.loadCurrentPermisions($scope.user.permissions);
         $scope.passwdRequired = true;
        $scope.save = function () {
            if ($scope.canSave() === true) {
                $scope.user.$save(function () {
                    growl.addSuccessMessage(Config.messages.susess, {ttl: Config.successTtl});
                    $state.go('^.', null, {reload: true});
                });
            }
        };
    }]);
