'use strict';
/**
 * @ngdoc controller
 * @name adminApp.baseOauthClientCtrl
 * @description
 * # baseOauthClientCtrl
 * Control in the adminApp.
 */
angular.module('adminApp').controller('baseOauthClientCtrl', ['$scope', 'OauthClient',
    function ($scope, OauthClient) {
        $scope.oauthClient = new OauthClient({actions: []});
        $scope.show = {delete: false, save: true, undo: true};
        $scope.editable = {id: true};
        $scope.original = angular.copy($scope.oauthClient);
        $scope.canSave = function () {
            return $scope.frmOauthClient.$valid;
        };
        $scope.canRevert = function () {
            return !angular.equals($scope.action, $scope.original);
        };
        $scope.reset = function () {
            $scope.oauthClient = angular.copy($scope.original);
            $scope.frmOauthClient.$setPristine();
        };
    }]);
