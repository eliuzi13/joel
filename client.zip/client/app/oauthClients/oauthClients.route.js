'use strict';
angular.module('adminApp')
        .config(function ($stateProvider) {
            $stateProvider.state('oauthClients', {
                url: '/oauth_clients',
                views: {
                    'main@': {
                        templateUrl: 'app/oauthClients/oauthClients.list.html',
                        controller: 'listOauthClientCtrl'
                    }
                }
            }).state('oauthClients.new', {
                url: '/new',
                views: {
                    'main@': {
                        templateUrl: 'app/oauthClients/oauthClients.form.html',
                        controller: 'creatOauthClientCtrl'
                    }
                }
            }).state('oauthClients.edit', {
                url: '/edit/:id',
                views: {
                    'main@': {
                        templateUrl: 'app/oauthClients/oauthClients.form.html',
                        controller: 'updateOauthClientCtrl'
                    }
                }
            });
        });