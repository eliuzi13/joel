'use strict';

/**
 * @ngdoc service
 * @name adminApp.OauthClient
 * @description
 * # OauthClient
 * Service in the adminApp.
 */

angular.module('adminApp').factory('OauthClient', ['Config', '$resource', function (Config, $resource) {
        return $resource(Config.url + Config.urlSecurity + '/oauth_client/:id',
                {'id': '@id'}, {'update': {method: 'PUT'}, 'restore': {method: 'PUT', url: Config.url + Config.urlSecurity + '/oauth_client/restore/:id'},
            'query': {method: 'GET', isArray: false, url: Config.url + Config.urlSecurity + '/oauth_client'}});

    }]);
