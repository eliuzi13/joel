'use strict';
/**
 * @ngdoc controller
 * @name adminApp.updateOauthClientCtrl
 * @description
 * # updateOauthClientCtrl
 * Controller in the adminApp.
 */
angular.module('adminApp').controller('updateOauthClientCtrl', ['$scope', '$controller', 'growl', 'Config', '$state', 'OauthClient',
    function ($scope, $controller, growl, Config, $state, OauthClient) {
        angular.extend(this, $controller('baseOauthClientCtrl', {$scope: $scope}));
        $scope.show = {delete: true, save: true, undo: true};
        $scope.editable = {id: false};
        $scope.oauthClient = OauthClient.get({id:$state.params.id});
        $scope.save = function () {
            if ($scope.canSave()) {
                $scope.oauthClient.$update(function () {
                    growl.addSuccessMessage(Config.messages.susess, {ttl: Config.successTtl});
                    $state.go('^.');
                });
            }
        };
    }]);
