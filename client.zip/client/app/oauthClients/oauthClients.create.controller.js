'use strict';
/**
 * @ngdoc controller
 * @name adminApp.creatOauthClientCtrl
 * @description
 * # creatOauthClientCtrl
 * Controller in the adminApp.
 */
angular.module('adminApp').controller('creatOauthClientCtrl', ['$scope', '$controller', 'growl', 'Config', '$state',
    function ($scope, $controller, growl, Config, $state) {
        angular.extend(this, $controller('baseOauthClientCtrl', {$scope: $scope}));
        $scope.save = function () {
            if ($scope.canSave() === true) {
                $scope.oauthClient.$save(function () {
                    growl.addSuccessMessage(Config.messages.susess, {ttl: Config.successTtl});
                    $state.go('^.', null, {reload: true});
                });
            }
        };
    }]);
