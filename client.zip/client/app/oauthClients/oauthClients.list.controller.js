'use strict';
/**
 * @ngdoc controller
 * @name adminApp.listOauthClientCtrl
 * @description
 * # listOauthClientCtrl
 * Controller in the adminApp.
 */
angular.module('adminApp').controller('listOauthClientCtrl', ['$scope', 'OauthClient', '$state', 'growl', 'Config',
    function ($scope, OauthClient, $state, growl, Config) {
         $scope.query = {withTrashed: '0'};
        $scope.search = function (params) {
            var obj = angular.extend(angular.copy($scope.query), params);
            $scope.oauthClients = OauthClient.query(obj);
        };
        $scope.edit = function (id) {
            $state.go('.edit', {id: id});
        };
        $scope.new = function () {
            $state.go('.new');
        };
        $scope.delete = function (id) {
            var _oauthClient = new OauthClient({id: id});
            _oauthClient.$delete(function () {
                growl.addSuccessMessage(Config.messages.delete, {ttl: Config.successTtl});
                $scope.search({page: $scope.query.page});
            });
        };
        $scope.restore = function (id) {
            var _oauthClient = new OauthClient({id: id});
            _oauthClient.$restore(function () {
                growl.addSuccessMessage(Config.messages.recovery, {ttl: Config.successTtl});
                $scope.search({page: $scope.query.page});
            });
        };
         $scope.toggleTrash = function () {
            if ($scope.query.withTrashed === '0') {
                $scope.query.withTrashed = '1';
            } else {
                $scope.query.withTrashed = '0';
            }
            $scope.search({});
        };
         $scope.search({});

    }]);
