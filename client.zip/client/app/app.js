'use strict';

angular.module('adminApp', [
    'ngCookies',
    'ngResource',
    'ngSanitize',
    'ui.router',
    'ui.bootstrap',
    'angular-growl',
    'security',
    'cfp.loadingBar'
]).constant('Config', {
    url: 'http://localhost/pets/api/public',
    client: {client: '0', secret: '123456'},
    urlSecurity: '/security',
    successTtl: 5000,
    messages: {susess: '<span class="glyphicon glyphicon-ok" ></span> Se guardo con éxito',
        delete: '<span class="glyphicon glyphicon-ok" ></span> Se elimino con éxito',
        recovery: '<span class="glyphicon glyphicon-ok" ></span> Se restauro con éxito'}
}).config(function ($urlRouterProvider) {
    $urlRouterProvider
            .otherwise('/');

    // $locationProvider.html5Mode(true);
}).constant('paginationConfig', {
    boundaryLinks: true,
    directionLinks: true,
    firstText: 'First',
    previousText: 'Back',
    nextText: 'Next',
    lastText: 'Last',
    rotate: true
});
