'use strict';
/**
 * @ngdoc controller
 * @name adminApp.creatRolCtrl
 * @description
 * # creatRolCtrl
 * Controller in the adminApp.
 */
angular.module('adminApp').controller('creatRolCtrl', ['$scope', '$controller', 'growl', 'Config', '$state',
    function ($scope, $controller, growl, Config, $state) {
        angular.extend(this, $controller('baseRolCtrl', {$scope: $scope}));
         $scope.loadCurrentPermisions($scope.rol.permissions);
        $scope.save = function () {
            if ($scope.canSave() === true) {
                $scope.rol.$save(function () {
                    growl.addSuccessMessage(Config.messages.susess, {ttl: Config.successTtl});
                    $state.go('^.', null, {reload: true});
                });
            }
        };
    }]);
