'use strict';
/**
 * @ngdoc controller
 * @name adminApp.baseRolCtrl
 * @description
 * # baseRolCtrl
 * Control in the adminApp.
 */
angular.module('adminApp').controller('baseRolCtrl', ['$scope', 'Rol', '$filter', 'Module',
    function ($scope, Rol, $filter, Module) {
        var _roles;
        $scope.rol = new Rol({permissions: [], modules: []});
        $scope.show = {delete: false, save: true, undo: true};
        $scope.original = angular.copy($scope.rol);
        $scope.canSave = function () {
            return $scope.frmRol.$valid;
        };
        $scope.canRevert = function () {
            return !angular.equals($scope.rol, $scope.original);
        };
        $scope.reset = function () {
            $scope.rol = angular.copy($scope.original);
            $scope.frmRol.$setPristine();
        };
        //
        $scope.loadCurrentPermisions = function (permissions) {

            if (_roles === undefined) {
                Module.query({showActions: 1, paginate: '0'}, function (response) {
                    angular.forEach(response.data, function (value) {
                        angular.forEach(value.actions, function (sub) {
                            sub.key = value.name + '.' + sub.name;
                        });
                    });
                    _roles = response.data;
                    setPermisos(permissions);
                });
            } else {
                setPermisos(permissions);
            }

        };
        function setPermisos(permissions) {
            angular.forEach(_roles, function (value) {
                angular.forEach(value.actions, function (sub) {
                    sub.module = undefined;
                });
            });
            angular.forEach(permissions, function (value, key) {
                $filter('filter')(_roles, {actions: key}, function (current, permiso) {
                    if (current.key === permiso) {
                        current.permiso = value;
                        return true;
                    }
                });
            });
            $scope.modules = _roles;
        }
        $scope.changeState2 = function (action) {
            if (action.permiso === undefined ||
                    action.permiso === false) {
                action.permiso = true;
            } else if (action.permiso === true) {
                action.permiso = false;
            }
            $scope.rol.permissions[action.key] = action.permiso;
        };

        $scope.checkAll = function ($index) {
            if ($scope.modules[$index].state === undefined ||
                    $scope.modules[$index].state === 0) {
                $scope.modules[$index].state = 1;
            } else if ($scope.modules[$index].state === 1) {
                $scope.modules[$index].state = 0;
            }
            var len = $scope.modules[$index].actions.length;
            for (var i = len - 1; i >= 0; i--) {
                if($scope.modules[$index].state === 0){
                    $scope.modules[$index].actions[i].permiso = false;
                    $scope.rol.permissions[ $scope.modules[$index].actions[i].key] = false;
                }else{
                    $scope.modules[$index].actions[i].permiso = true;
                    $scope.rol.permissions[ $scope.modules[$index].actions[i].key] = true;
                }
                
                //$scope.rol.permissions[ $scope.modules[$index].actions[i].key] = $scope.modules[$index].state;
            }
        };

        $scope.toggle = function ($index) {
            $scope.modules[$index].show = !$scope.modules[$index].show;
        };

        $scope.toggleClass = function ($index) {
            if ($scope.modules[$index].show === undefined) {
                $scope.modules[$index].show = false;
            }


            return {
                'fa fa-caret-down': $scope.modules[$index].show === true,
                'fa fa-caret-right': $scope.modules[$index].show === false
            };
        };

        $scope.getClass = function ($index) {
            var partial, all, ban = false;
            var cant, bann, total = 0;
            cant = $filter('filter')($scope.modules[$index].actions, {permiso: true}, true).length;
            bann = $filter('filter')($scope.modules[$index].actions, {permiso: false}, function (current) {
                if (angular.isUndefined(current) === true || current === 0) {
                    return true;
                }
            }).length;
            total = $scope.modules[$index].actions.length;
            if (cant === total) {
                all = true;
                $scope.modules[$index].state = 1;
            } else if (bann === total) {
                ban = true;
            } else if (cant > 0 || bann > 0) {
                partial = true;
            } else {
                ban = true;
            }
            return  {
                'fa fa-circle text-success': all,
                'fa fa-ban text-danger': ban,
                'fa fa-dot-circle-o text-muted': partial
            };
        };


        $scope.getClass2 = function (value) {
            return {
                'fa fa-circle text-success': value === true,
                'fa fa-ban text-danger': value === false || value === undefined
            };

        };
    }]);
