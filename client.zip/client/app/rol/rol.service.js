'use strict';

/**
 * @ngdoc service
 * @name adminApp.Rol
 * @description
 * # Rol
 * Service in the adminApp.
 */

angular.module('adminApp').factory('Rol', ['Config', '$resource', function (Config, $resource) {
        return $resource(Config.url + Config.urlSecurity + '/roles/:id',
                {'id': '@id'}, {'update': {method: 'PUT'}, 'restore': {method: 'PUT', url: Config.url + Config.urlSecurity + '/roles/restore/:id'},
            'query': {method: 'GET', isArray: false, url: Config.url + Config.urlSecurity + '/roles'}});

    }]);
