'use strict';
/**
 * @ngdoc controller
 * @name adminApp.updateActioCtrl
 * @description
 * # updateActioCtrl
 * Controller in the adminApp.
 */
angular.module('adminApp').controller('updateRolCtrl', ['$scope', '$controller', 'growl', 'Config', '$state', 'Rol',
    function ($scope, $controller, growl, Config, $state, Rol) {
        angular.extend(this, $controller('baseRolCtrl', {$scope: $scope}));
        $scope.show = {delete: true, save: true, undo: true};
        $scope.rol = Rol.get({id: $state.params.id}, function (response) {
            $scope.rol = response;
            $scope.rol.permissions = angular.fromJson($scope.rol.permissions);
            if ($scope.rol.permissions.length === 0)
            {
                $scope.rol.permissions = {};
            }
            $scope.loadCurrentPermisions($scope.rol.permissions);
        });

        $scope.save = function () {
            if ($scope.canSave()) {
                $scope.rol.$update(function () {
                    growl.addSuccessMessage(Config.messages.susess, {ttl: Config.successTtl});
                    $state.go('^.');
                });
            }
        };
    }]);
