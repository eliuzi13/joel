'use strict';
angular.module('adminApp')
        .config(function ($stateProvider) {
            $stateProvider.state('roles', {
                url: '/roles',
                views: {
                    'main@': {
                        templateUrl: 'app/rol/rol.list.html',
                        controller: 'listRolCtrl'
                    }
                }
            }).state('roles.new', {
                url: '/new',
                views: {
                    'main@': {
                        templateUrl: 'app/rol/rol.form.html',
                        controller: 'creatRolCtrl'
                    }
                }
            }).state('roles.edit', {
                url: '/edit/:id',
                views: {
                    'main@': {
                        templateUrl: 'app/rol/rol.form.html',
                        controller: 'updateRolCtrl'
                    }
                }
            });
        });