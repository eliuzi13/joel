'use strict';

/**
 * @ngdoc service
 * @name adminApp.Module
 * @description
 * # Module
 * Service in the adminApp.
 */

angular.module('adminApp').factory('Module', ['Config', '$resource', function (Config, $resource) {
        return $resource(Config.url + Config.urlSecurity + '/modules/:id',
                {'id': '@id'}, {'update': {method: 'PUT'}, 'restore': {method: 'PUT', url: Config.url + Config.urlSecurity + '/modules/restore/:id'},
            'query': {method: 'GET', isArray: false, url: Config.url + Config.urlSecurity + '/modules'}});

    }]);
