'use strict';
angular.module('adminApp')
        .config(function ($stateProvider) {
            $stateProvider.state('modules', {
                url: '/modules',
                views: {
                    'main@': {
                        templateUrl: 'app/module/module.list.html',
                        controller: 'listModuleCtrl'
                    }
                }
            }).state('modules.new', {
                url: '/new',
                views: {
                    'main@': {
                        templateUrl: 'app/module/module.form.html',
                        controller: 'creatModuleCtrl'
                    }
                }
            }).state('modules.edit', {
                url: '/edit/:id',
                views: {
                    'main@': {
                        templateUrl: 'app/module/module.form.html',
                        controller: 'updateModuleCtrl'
                    }
                }
            });
        });