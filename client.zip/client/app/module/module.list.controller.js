'use strict';
/**
 * @ngdoc controller
 * @name adminApp.listModuleCtrl
 * @description
 * # listModuleCtrl
 * Controller in the adminApp.
 */
angular.module('adminApp').controller('listModuleCtrl', ['$scope', 'Module', '$state', 'growl', 'Config',
    function ($scope, Module, $state, growl, Config) {
        $scope.query = {withTrashed: '0'};
        $scope.search = function (params) {
            var obj = angular.extend(angular.copy($scope.query), params);
            $scope.modules = Module.query(obj);
        };
        $scope.edit = function (id) {
            $state.go('.edit', {id: id});
        };
        $scope.new = function () {
            $state.go('.new');
        };
        $scope.delete = function (id) {
            var _module = new Module({id: id});
            _module.$delete(function () {
                growl.addSuccessMessage(Config.messages.delete, {ttl: Config.successTtl});
                $scope.search({page: $scope.query.page});
            });
        };
        $scope.restore = function (id) {
            var _module = new Module({id: id});
            _module.$restore(function () {
                growl.addSuccessMessage(Config.messages.recovery, {ttl: Config.successTtl});
                $scope.search({page: $scope.query.page});
            });
        };
        $scope.toggleTrash = function () {
            if ($scope.query.withTrashed === '0') {
                $scope.query.withTrashed = '1';
            } else {
                $scope.query.withTrashed = '0';
            }
            $scope.search({});
        };
        $scope.search({});

    }]);
