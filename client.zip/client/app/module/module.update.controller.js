'use strict';
/**
 * @ngdoc controller
 * @name adminApp.updateModuleCtrl
 * @description
 * # updateModuleCtrl
 * Controller in the adminApp.
 */
angular.module('adminApp').controller('updateModuleCtrl', ['$scope', '$controller', 'growl', 'Config', '$state', 'Module',
    function ($scope, $controller, growl, Config, $state, Module) {
        angular.extend(this, $controller('baseModuleCtrl', {$scope: $scope}));
        $scope.show = {delete: true, save: true, undo: true};
        $scope.module = Module.get({id:$state.params.id});
        $scope.save = function () {
            if ($scope.canSave()) {
                $scope.module.$update(function () {
                    growl.addSuccessMessage(Config.messages.susess, {ttl: Config.successTtl});
                    $state.go('^.');
                });
            }
        };
    }]);
