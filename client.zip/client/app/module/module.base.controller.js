'use strict';
/**
 * @ngdoc controller
 * @name adminApp.baseModuleCtrl
 * @description
 * # baseModuleCtrl
 * Control in the adminApp.
 */
angular.module('adminApp').controller('baseModuleCtrl', ['$scope', 'Module', 'Action',
    function ($scope, Module, Action) {
        $scope.module = new Module({actions: []});
        $scope.show = {delete: false, save: true, undo: true};
        $scope.original = angular.copy($scope.module);
        $scope.canSave = function () {
            return $scope.frmModule.$valid;
        };
        Action.query({paginate: 0}, function (response) {
            $scope.actions = response.data;
        });
        $scope.canRevert = function () {
            return !angular.equals($scope.action, $scope.original);
        };
        $scope.reset = function () {
            $scope.module = angular.copy($scope.original);
            $scope.frmModule.$setPristine();
        };
    }]);
