'use strict';
/**
 * @ngdoc controller
 * @name adminApp.creatModuleCtrl
 * @description
 * # creatModuleCtrl
 * Controller in the adminApp.
 */
angular.module('adminApp').controller('creatModuleCtrl', ['$scope', '$controller', 'growl', 'Config', '$state',
    function ($scope, $controller, growl, Config, $state) {
        angular.extend(this, $controller('baseModuleCtrl', {$scope: $scope}));
        $scope.save = function () {
            if ($scope.canSave() === true) {
                $scope.module.$save(function () {
                    growl.addSuccessMessage(Config.messages.susess, {ttl: Config.successTtl});
                    $state.go('^.', null, {reload: true});
                });
            }
        };
    }]);
