(function(angular, undefined) {
'use strict';

angular.module('adminApp.constants', [])

.constant('appConfig', {userRoles:['guest','user','admin']})

;
})(angular);