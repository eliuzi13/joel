'use strict';
/**
 * @ngdoc contuserler
 * @name adminApp.userProfileCtrl
 * @description
 * # userProfileCtrl
 * Contuserler in the adminApp.
 */
angular.module('adminApp').controller('userProfileCtrl', ['$scope', 'security',
    function ($scope, security) {
            $scope.user = security.currentUser;
    }]);
