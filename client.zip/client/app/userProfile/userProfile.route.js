'use strict';
angular.module('adminApp')
        .config(function ($stateProvider) {
            $stateProvider.state('profile', {
                url: '/user/profile',
                views: {
                    'main@': {
                        templateUrl: 'app/userProfile/userProfile.form.html',
                        controller: 'userProfileCtrl'
                    }
                }
            });
        });