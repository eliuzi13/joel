'use strict';
angular.module('adminApp')
        .config(function ($stateProvider) {
            $stateProvider.state('action', {
                url: '/action',
                views: {
                    'main@': {
                        templateUrl: 'app/action/action.list.html',
                        controller: 'listActionCtrl'
                    }
                }
            }).state('action.new', {
                url: '/new',
                views: {
                    'main@': {
                        templateUrl: 'app/action/action.form.html',
                        controller: 'creatActionCtrl'
                    }
                }
            }).state('action.edit', {
                url: '/edit/:id',
                views: {
                    'main@': {
                        templateUrl: 'app/action/action.form.html',
                        controller: 'updateActioCtrl'
                    }
                }
            });
        });