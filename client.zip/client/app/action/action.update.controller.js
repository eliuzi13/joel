'use strict';
/**
 * @ngdoc controller
 * @name adminApp.updateActioCtrl
 * @description
 * # updateActioCtrl
 * Controller in the adminApp.
 */
angular.module('adminApp').controller('updateActioCtrl', ['$scope', '$controller', 'growl', 'Config', '$state', 'Action',
    function ($scope, $controller, growl, Config, $state, Action) {
        angular.extend(this, $controller('baseActionCtrl', {$scope: $scope}));
        $scope.show = {delete: true, save: true, undo: true};
        $scope.action = Action.get({id:$state.params.id});
        $scope.save = function () {
            if ($scope.canSave()) {
                $scope.action.$update(function () {
                    growl.addSuccessMessage(Config.messages.susess, {ttl: Config.successTtl});
                    $state.go('^.');
                });
            }
        };
    }]);
