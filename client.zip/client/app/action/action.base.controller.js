'use strict';
/**
 * @ngdoc controller
 * @name adminApp.baseActionCtrl
 * @description
 * # baseActionCtrl
 * Control in the adminApp.
 */
angular.module('adminApp').controller('baseActionCtrl', ['$scope', 'Action',
    function ($scope, Action) {
        $scope.action = new Action();
        $scope.show = {delete: false, save: true, undo: true};
        $scope.original = angular.copy($scope.action);
        $scope.canSave = function () {
            return $scope.frmAction.$valid;
        };
        $scope.canRevert = function () {
            return !angular.equals($scope.action, $scope.original);
        };
        $scope.reset = function () {
            $scope.action = angular.copy($scope.original);
            $scope.frmAction.$setPristine();
        };
    }]);
