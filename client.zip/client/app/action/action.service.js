'use strict';

/**
 * @ngdoc service
 * @name adminApp.Action
 * @description
 * # Action
 * Service in the espaciosIrApp.
 */

angular.module('adminApp').factory('Action', ['Config', '$resource', function (Config, $resource) {
        return $resource(Config.url + Config.urlSecurity + '/actions/:id',
                {'id': '@id'}, {'update': {method: 'PUT'}, 'restore': {method: 'PUT', url: Config.url + Config.urlSecurity + '/actions/restore/:id'},
            'query': {method: 'GET', isArray: false, url: Config.url + Config.urlSecurity + '/actions'}});

    }]);
