'use strict';
/**
 * @ngdoc controller
 * @name adminApp.creatActionCtrl
 * @description
 * # creatActionCtrl
 * Controller in the adminApp.
 */
angular.module('adminApp').controller('creatActionCtrl', ['$scope', '$controller', 'growl', 'Config', '$state',
    function ($scope, $controller, growl, Config, $state) {
        angular.extend(this, $controller('baseActionCtrl', {$scope: $scope}));
        $scope.save = function () {
            if ($scope.canSave() === true) {
                $scope.action.$save(function () {
                    growl.addSuccessMessage(Config.messages.susess, {ttl: Config.successTtl});
                    $state.go('^.', null, {reload: true});
                });
            }
        };
    }]);
