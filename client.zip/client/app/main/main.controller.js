'use strict';


angular.module('adminApp')
        .controller('MainController', ['$scope', '$http', function ($scope, $http) {
                $scope.awesomeThings = [];
                this.$http = $http;
                this.awesomeThings = [];

                $http.get('/api/things').then(function (response) {
                    this.awesomeThings = response.data;
                });
            }]);
