'use strict';

angular.module('adminApp')
        // =========================================================================
        // Base controller for common functions
        // =========================================================================

        .controller('mamagerCtrl', ['$timeout', '$state', 'security', '$rootScope', 'Config',
            function ($timeout, $state, security, $rootScope, Config) {
                //Welcome Message
                //growlService.growl('Welcome back Mallinda!', 'inverse')

                var $this = this;
                //Get current User
                this.currentUser = {};
                this.roles = Config.roles;
                this.textHeader = '';
                this.isAuthenticated = security.isAuthenticated();
                this.parseFloat = function(number){
                    return parseFloat(number);
                };
                $rootScope.$on('userChange', function () {
                    $this.currentUser = security.currentUser;
                    $this.isAuthenticated = security.isAuthenticated();
                });
                $rootScope.$on('loginOff', function () {
                    $this.isAuthenticated = false;
                });

                //logout
                $this.logout = security.logout;

                // Detact Mobile Browser
                if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
                    angular.element('html').addClass('ismobile');
                }
            }]);


