'use strict';
 // -------------------------------------------------- //
        // -------------------------------------------------- //
        // This CSS class-based directive controls the pre-bootstrap loading screen. By
        // default, it is visible on the screen; but, once the application loads, we'll
        // fade it out and remove it from the DOM.
        // --
        // NOTE: Normally, I would probably just jQuery to fade-out the container; but,
        // I thought this would be a nice moment to learn a bit more about AngularJS
        // animation. As such, I'm using the ng-leave workflow to learn more about the
        // ngAnimate module.
        angular.module('adminApp').directive('mAppLoading', ['$rootScope', function ($rootScope) {
                // I bind the JavaScript events to the scope.
                function link(scope, element, attributes) {
                    $rootScope.$on('cfpLoadingBar:completed', function () {
                        if (element !== null) {
                            setTimeout(function asyncLoad() {
                                if (element !== null) {
                                    // Remove the root directive element.
                                    element.remove();
                                    // Clear the closed-over variable references.
                                    scope = element = attributes = null;
                                }
                            }, (500));
                        }
                    });
                }
                // Return the directive configuration.
                return({
                    link: link,
                    restrict: 'C'
                });

            }]);

   