'use strict';
angular.module('adminApp')
        .directive('tableFilter', ['$timeout', '$compile', function ($timeout, $compile) {
                return {
                    restrict: 'A',
                    require: '^ngModel',
                    scope: {
                        ngModel: '=',
                        timeout: '@',
                        placeholder: '@',
                        label: '@',
                        options: '=',
                        type: '@',
                        change: '=',
                        sortable: '=',
                        showInput: '=',
                        ngFilter: '@'
                    },
                    link: function postLink(scope, element, attrs) {
                        scope.order = 'asc';
                        var filterTextTimeout, timeout = (attrs.timeout) ? attrs.timeout : 800;
                        if (scope.ngModel === undefined) {
                            scope.ngModel = {};
                        }
                        scope.action = function () {
                            if (scope.sortable) {
                                scope.ngModel.order = (scope.ngModel.order === 'asc') ? 'desc' : 'asc';
                                scope.ngModel.sort = scope.ngFilter;
                                scope.change();
                            }
                        };
                        scope.viewSort = function () {
                            return scope.sortable && scope.ngFilter === scope.ngModel.sort;
                        };
                        var getTemplate = function () {
                            var template = '<div ng-click="action()" ng-class="{\'t-sortable\':sortable===true}"><i class="zmdi"' +
                                    ' ng-class="{\'zmdi-sort-amount-asc\': ngModel.order==\'asc\',\'zmdi-sort-amount-desc\':ngModel.order==\'desc\'}"' +
                                    ' ng-if="viewSort()"></i> <span>{{label}}</span></div>';
                            template += '<div ng-if="showInput" ><input class="input-filter form-control input-sm" ng-model="ngModel.' + scope.ngFilter + '" /></div>';

                            return template;
                        };
                        scope.$watch('ngModel.' + scope.ngFilter, function (val) {
                            if (val === undefined) {
                                return;
                            }
                            if (filterTextTimeout) {
                                $timeout.cancel(filterTextTimeout);
                            }
                            filterTextTimeout = $timeout(function () {
                                scope.change();
                            }, timeout);
                        }, true);
                        element.html(getTemplate(scope.type)).show();
                        $compile(element.contents())(scope);
                    }
                };
            }]);
