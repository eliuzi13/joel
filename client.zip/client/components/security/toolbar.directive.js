'use strict';
angular.module('security.login.toolbar', [])
.directive('loginToolbar', ['security', function(security) {
	var directive = {
		templateUrl: 'components/security/toolbar.tpl.html',
		restrict: 'E',
		replace: true,
		scope: true,
		link: function($scope) {
			$scope.isAuthenticated = security.isAuthenticated;
			$scope.login = security.showLogin;
			$scope.logout = security.logout;
			$scope.$watch(function() {
				return security.currentUser;
			}, function(currentUser) {
				$scope.currentUser = currentUser;
			});
		}
	};
	return directive;
}])

.directive('isAuthenticated', ['security','$rootScope',function(security) {
	return  {
		restrict: 'A',
		link: function($scope,elem) {
			$scope.$watch(function() {
				if(security.currentUser===null || angular.isUndefined(security.currentUser)){
					elem.fadeOut();
				}else{
					elem.fadeIn();
				}
			}, function(currentUser) {
				$scope.currentUser = currentUser;
			});


		}
	};

}]);


