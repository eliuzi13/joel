'use strict';
angular.module('security.login.form', [])
        //
        .controller('LoginFormController', ['$scope', '$rootScope', 'security', '$timeout', '$state',
            //
            function ($scope, $rootScope, security, $timeout, $state) {
                $scope.user = {};
                $scope.reason = security.getLoginReason();
                $scope.authError = null;

                $scope.entrar = function (e) {
                    var code = e.keyCode || e.which;
                    if (code === 13) {
                        e.preventDefault();
                        $scope.login();
                    }

                };

                $scope.authReason = null;

                if (!security.isAuthenticated()) {
                    $scope.authReason = null;
                } else if (security.getLoginReason() === 'u2fAuth-required' || security.getLoginReason() === 'u2fSession-required') {
                    $scope.authReason = 'Autenticación de dos pasos solicitada';
                } else {
                    $scope.authReason = 'El usuario no tiene suficientes permisos, ingrese usuario con permisos o cancele la acción';
                }

                $scope.showForm = function () {
                    return security.getLoginReason() !== 'u2fAuth-required' && security.getLoginReason() !== 'u2fSession-required';
                };

                $scope.execTimer = function (atime) {
                    $scope.timer = atime;
                    $scope.timeout = $timeout(function () {
                        atime = atime - 1;
                        $scope.execTimer(atime);
                    }, 1000);
                };

                $rootScope.$on('keyCheck', function (event, data) {
                    $scope.responseChallenge(data.data, data.reason);
                });

                $scope.responseChallenge = function (req, reason) {
                    if (reason === 'u2fAuth-required' || reason === 'u2fSession-required') {
                        $timeout.cancel($scope.timeout);
                        $scope.execTimer(30);

                        new U2fService(req, reason).then(null, function (error) {
                            $scope.keyError = error;
                            security.cancelLogin();
                            $scope.showForm();
                        });

                    }
                };


                $scope.$on('$destroy', function () {
                    $timeout.cancel($scope.timeout);
                });



                $scope.responseChallenge(security.getExtraData(), security.getLoginReason());


                $scope.login = function () {
                    $scope.authError = null;
                    security.login($scope.user.email, $scope.user.password, $scope.user.remember).then(function () {
                        $state.go('main', null, {reload: true});

                    }, function () {
                        $scope.authError = 'login.error.serverError';
                    });
                };

                $scope.clearForm = function () {
                    $scope.user = {};
                };

                $scope.cancelLogin = function () {

                };

            }]).controller('LoginModalController', ['$scope', '$controller', '$modalInstance',
    function ($scope, $controller, $modalInstance) {
        angular.extend(this, $controller('LoginFormController', {$scope: $scope}));
        $scope.cancelLogin = function () {
            $modalInstance.close(false);
        };
    }]);