// Based loosely around work by Witold Szczerba - https://github.com/witoldsz/angular-http-auth
'use strict';
angular.module('security', [
    'security.service',
    'security.interceptor',
    'security.login',
    'security.authorization'
]).config(function ($stateProvider) {
    $stateProvider
            .state('login', {
                url: '/login',
                views: {
                    'login@': {
                        templateUrl: 'components/security/login.form.html',
                        controller: 'LoginFormController'
                    }
                }
            });
});
