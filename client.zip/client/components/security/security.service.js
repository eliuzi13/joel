'use strict';

angular.module('security.service', [
    'security.retryQueue',
    'security.login',
    'ui.bootstrap'
]).factory('security',
        ['$http', '$q', '$location', 'securityRetryQueue', '$modal', '$rootScope', 'Config','$state',
            function ($http, $q, $location, queue, $modal, $rootScope, Config,$state) {


                function redirect(state) {
                    console.log(state);
                    $state.go(state,{},{inherit:false,reload:true});
                }

                var loginDialog = null;
//                function openLoginDialog() {
//
//                    $rootScope.$broadcast('security.dialog.open');
//
//                    if (!loginDialog) {
//                        loginDialog = $modal.open({
//                            templateUrl: 'components/security/form.tpl.html',
//                            controller: 'LoginModalController',
//                            windowClass: 'modal-info',
//                            keyboard: false,
//                            backdrop: 'static'
//                        });
//
//                        loginDialog.result.then(onLoginDialogClose, closeLoginDialog);
//                    }
//                }

                function closeLoginDialog(success) {
                    if (loginDialog) {
                        loginDialog.close(success);
                        loginDialog = null;
                    }
                }
//                function onLoginDialogClose(success) {
//                    if (success) {
//                        queue.retryAll();
//                        loginDialog = null;
//                        $rootScope.$broadcast('security.dialog.close');
//                    } else {
//                        queue.cancelAll();
//                        loginDialog = null;
//                        redirect();
//                    }
//                }
                function setCurretnUser(user) {
                    service.currentUser = user;
                    $rootScope.$broadcast('userChange');
                }


                queue.onItemAddedCallbacks.push(function () {

                    if (queue.hasMore()) {
                        service.showLogin();
                    }
                });


                var service = {
                    getLoginReason: function () {
                        return queue.retryReason();
                    },
                    getExtraData: function () {
                        return queue.extraData();
                    },
                    showLogin: function () {
                        //openLoginDialog();
                        $rootScope.$broadcast('loginOff');
                        $state.go('login', null, {reload: true});
                        
                    },
                    login: function (email, password,remember) {
                        var defer = $q.defer();
                        $http.post(Config.url + '/auth/web_login', {login: email, password: password,remember:remember})
                                .success(function (response) {
                                    setCurretnUser(response);
                                    $rootScope.$broadcast('loginOn');
                                    defer.resolve(response);
                                    if (service.isAuthenticated()) {
                                        closeLoginDialog(true);
                                    }
                                }).error(function () {
                            defer.reject('error al autenticarse');
                        });
                        return defer.promise;
                    },
                    u2fCheck: function (response) {
                        var defer = $q.defer();
                        $http.post(Config.url + '/security/u2fcheck', response)
                                .success(function (response) {
                                    defer.resolve(response);
                                    service.requestCurrentUser().then(function () {
                                        if (service.isAuthenticated()) {
                                            closeLoginDialog(true);
                                        }
                                    });

                                }).error(function () {
                            defer.reject('error en la llave');
                        });
                        return defer.promise;
                    },
                    cancelLogin: function () {


                        queue.cancelAll();
                        //closeLoginDialog(true);
                        redirect();
                    },
                    logout: function (redirectTo) {

                        $http.get(Config.url + '/auth/web_logout').success(function () {
                            setCurretnUser(null);
                            $rootScope.$broadcast('loginOff');
                            redirect(redirectTo);
                        });
                    },
                    requestCurrentUser: function () {
                        if (service.isAuthenticated()) {
                            return $q.when(service.currentUser);
                        } else {
                            return $http.get(Config.url + '/auth/web_curretn_user').success(function (response) {
                                setCurretnUser(response);
                                service.propAccess();
                                return service.currentUser;
                            });
                        }
                    },
                    currentUser: null,
                    isAuthenticated: function () {
                        return !!service.currentUser;
                    },
                    propAccess: function () {
                        if (service.currentUser) {
                            var permissions = service.currentUser.permissions || {};
                            angular.forEach(permissions, function (value, key) {
                                $rootScope.$broadcast('permissions', {key: key, value: value});
                            });
                        }

                    },
                    hasAccess: function (action) {
                        if (service.currentUser.permissions.hasOwnProperty(action)) {
                            return true;
                        } else {
                            return false;
                        }
                    },
                    isAdmin: function () {
                        return !!(service.currentUser && service.currentUser.admin);
                    }
                };

                return service;

            }]);