'use strict';
angular.module('security.interceptor', ['security.retryQueue', 'angular-growl'])
        .factory('securityInterceptor', ['$injector', 'securityRetryQueue', '$rootScope', '$q',
            'growl', '$location', 'cfpLoadingBar', 'Config',
            function ($injector, queue, $rootScope, $q, growl, $location, cfpLoadingBar, Config) {
                return {
                    'request': function (config) {
                        cfpLoadingBar.start();
                        var client = btoa(Config.client.client + ':' + Config.client.secret);
                        config.headers = angular.extend(config.headers, {Client: client});
                        return config;
                    },
                    'requestError': function (rejection) {
                        cfpLoadingBar.start();
                        return $q.reject(rejection);
                    },
                    'response': function (response) {
                        cfpLoadingBar.complete();
                        return response;
                    },
                    'responseError': function (rejection) {
                        cfpLoadingBar.complete();
                        switch (rejection.status) {
                            case 401:

                                if (rejection.data.error.heading === 'U2fRequired') {

                                    return queue.pushRetryFn('u2fAuth-required', rejection.data.error.data, function retryRequest() {
                                        return $injector.get('$http')(rejection.config);
                                    });

                                } else if (rejection.data.error.heading === 'U2fSessionRequired') {
                                    queue.cancelAll();
                                    $rootScope.$broadcast('keyCheck', {data: rejection.data.error.data, reason: 'u2fSession-required'});
                                    return queue.pushRetryFn('u2fSession-required', rejection.data.error.data, function retryRequest() {
                                        return $injector.get('$http')(rejection.config);
                                    });

                                } else {

                                    return queue.pushRetryFn('unauthorized-server', null, function retryRequest() {
                                        return $injector.get('$http')(rejection.config);
                                    });


                                }
                                break;

                            case 400:
                                var lista = '';
                                angular.forEach(rejection.data.error.message, function (obj) {
                                    lista += '<li>' + obj + '</li>';
                                });
                                growl.addErrorMessage('<i class="fa fa-exclamation-triangle"></i> ' + rejection.status + '- Error de petición<br/><ul>' + lista + '</ul>', {ttl: -1});
                                break;
                            case 404:
                                growl.addErrorMessage('<i class="fa fa-exclamation-triangle"></i> ' + rejection.status + '- Pagina no encontrada', {ttl: -1});
                                break;
                            case 500:
                                growl.addErrorMessage('<i class="fa fa-exclamation-triangle"></i> ' + rejection.status + '- ERROR', {ttl: -1});
                                break;
                            case 503:
                                $rootScope.manteniance = rejection.data;
                                $location.path('/down');
                                break;
                        }
                        return $q.reject(rejection);
                    }
                };
            }])

        .config(['growlProvider', '$httpProvider', function (growlProvider, $httpProvider) {
                growlProvider.globalEnableHtml(true);
                growlProvider.onlyUniqueMessages(false);
                $httpProvider.interceptors.push(growlProvider.serverMessagesInterceptor);
                $httpProvider.interceptors.push('securityInterceptor');
            }])

        .run(['Config', '$rootScope', 'security', 'growl', function (Config, $rootScope, security, growl) {
                $rootScope.$on('loginOff', function () {
                    growl.addSuccessMessage('Adios!', {ttl: Config.successTtl});
                });
                $rootScope.$on('loginOn', function () {
                    growl.addSuccessMessage('Bienvenido ' + security.currentUser.first_name + '!', {ttl: Config.successTtl});
                });
                security.requestCurrentUser();
            }]);






