'use strict';

angular.module('adminApp')
        .directive('slideMenu', function () {
            return{
                templateUrl: 'components/slideMenu/slideMenu.html',
                restrict: 'E',
                link: function () {
                    $('#side-menu').metisMenu();
                }
            };
        });
