'use strict';

angular.module('adminApp.util', []);
