'use strict';
angular.module('adminApp')
  .controller('NavbarController',  ['$scope','$location','security',
      function ($scope, $location,security) {
    $scope.menu = [{
      'title': 'Home',
    'state': 'main'
    }];

    $scope.isCollapsed = true;

    $scope.isActive = function(route) {
      return route === $location.path();
    };
    
    $scope.logout = function(redirectTo){
        security.logout(redirectTo);
    };
  }]);
