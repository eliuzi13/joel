<?php

namespace Pets\Http\Middleware;

use Closure;
use Illuminate\Contracts\Auth\Guard;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use Log;

class SentinelACL {

    /**
     * The Guard implementation.
     *
     * @var Guard
     */
    protected $auth;

    /**
     * Create a new filter instance.
     *
     * @param  Guard  $auth
     * @return void
     */
    public function __construct(Guard $auth) {
        $this->auth = $auth;
    }

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next) {
        $currentRouteName = $request->route()->getName();
        $user = Sentinel::getUser();
        Log::info($user);
        if (isset($user->id) === false || !$user->hasAccess($currentRouteName)) {
            return response()->json(array(
                        'error' => array(
                            'heading' => 'Sesión',
                            'message' => array('No tiene permisos para ejectuar esta acción'),
                            'session' => 1
                        )), 401);
        }

        return $next($request);
    }


}
