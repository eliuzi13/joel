<?php

namespace Pets\Http\Base;

use DB;
use Validator;

trait ExtendModel  {

    /**
     * Error message bag
     * 
     * @var Illuminate\Support\MessageBag
     */
    protected $errors;

    /**
     * Validator instance
     * 
     * @var Illuminate\Validation\Validators
     */
    protected $validator;

    /*
     *
     *   constructor 
     *
     */

    public function __construct(array $attributes = array(), Validator $validator = null) {
        parent::__construct($attributes);

        $this->validator = $validator ? : \App::make('validator');
    }

    public function scopeGetView($query, $view = false) {
        if ($view === false) {
            $view = $this->view;
        }
        $this->table = $this->view;
        return $this;
    }

    public function scopeSetAlias($query, $alias) {
        $this->table = $this->table . ' AS ' . $alias;
        return $this;
    }

    /**
     * Validates current attributes against rules
     */
    public function validate() {
        $pk = $this->{$this->primaryKey};
        $rules = [];
        if ($pk !== null) {
            foreach (static::$rules AS $name =>$rule) {
                $rules[$name] = str_replace(":id", $pk, $rule);
            }
        } else {
            $rules = static::$rules;
        }
        $v = $this->validator->make($this->attributes, $rules);
        if ($v->passes()) {
            return true;
        }
        $this->setErrors($v->messages());
        return false;
    }

    /**
     * Set error message bag
     * 
     * @var Illuminate\Support\MessageBag
     */
    protected function setErrors($errors) {
        $this->errors = $errors;
    }

    /**
     * Retrieve error message bag
     */
    public function getErrors() {
        return $this->errors;
    }

    /**
     * Inverse of wasSaved
     */
    public function hasErrors() {
        return !empty($this->errors);
    }

    public function responseError() {
        return response()->json(array(
                    'error' => array(
                        'heading' => 'Error de validación',
                        'message' => $this->getErrors())), 400);
    }

    public function scopeLike($query, $data) {
        foreach ($data AS $field => $value) {
            if ($value == '' || $value == null) {
                continue;
            }
            $parts = explode(' as ', strtolower($this->table));
            $table = (count($parts) === 2) ? trim($parts[1]) : trim($parts[0]);
            $query->where(DB::raw($table . '.' . $field), 'like', "%$value%");
        }
        return $query;
    }

    public function scopeDates($query, $campo, $fi, $ff) {
        if ($fi && $ff) {
            $fi = trim(str_replace('"', '', $fi));
            $fi = date('Y-m-d', strtotime($fi)) . ' 00:00:00';
            $ff = trim(str_replace('"', '', $ff));
            $ff = date('Y-m-d', strtotime($ff)) . ' 23:59:59';
            return $query->whereBetween($campo, array($fi, $ff));
        } else {
            return $query;
        }
    }

    public function scopeBetween($query, $campo, $fi, $ff) {
        if ($fi && $ff) {
            return $query->whereBetween($campo, array($fi, $ff));
        } else {
            return $query;
        }
    }

    public function scopeEqual($query, $data) {
        foreach ($data AS $field => $value) {
            if ($value == '' || $value == null) {
                continue;
            }
            $parts = explode(' as ', strtolower($this->table));
            $table = (count($parts) === 2) ? trim($parts[1]) : trim($parts[0]);
            $query->where($table . '.' . $field, '=', $value);
        }

        return $query;
    }

}
