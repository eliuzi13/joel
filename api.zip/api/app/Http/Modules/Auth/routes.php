<?php

/*
  |--------------------------------------------------------------------------
  | Application Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register all of the routes for an application.
  | It's a breeze. Simply tell Laravel the URIs it should respond to
  | and give it the controller to call when that URI is requested.
  |
 */

Route::group(['middleware' => ['web']], function() {
    /**
     * Recurso de login
     */
    Route::post('web_login', 'WebAhutController@login');

    /**
     * Recurso de login
     */
    Route::get('web_logout', 'WebAhutController@logout');

    /**
     * Recurso de login
     */
    Route::get('web_curretn_user', 'WebAhutController@current_user');
});
