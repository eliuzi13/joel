<?php

namespace Pets\Http\Modules\Auth\Controllers;

use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use Illuminate\Http\Request;
use Pets\Http\Base\Controller;
use Pets\Http\Modules\Security\Models\User;
use Exception;
use Log;

class WebAhutController extends Controller {

    public function current_user(Request $request) {
        if ($user = Sentinel::forceCheck()) {
            return response()->json($user, 200);
        } else {
            return response()->json(['error' => ['messages' => ['No ha iniciado sessión.']]], 401);
        }
    }

    public function login(Request $request) {
        $credentials = [
            'email' => $request->get('login', ''),
            'password' => $request->get('password', '')
        ];
        try {
            $data = explode(':', base64_decode($request->header('Client')));
            $client = (isset($data[0]) === true) ? $data[0] : false;
            $secret = (isset($data[1]) === true) ? $data[1] : false;
            if ($client === false) {
                throw new Exception("Cliente requerido.");
            }
            if ($secret === false) {
                throw new Exception("Secret requerido.");
            }
            $user = Sentinel::findByCredentials($credentials);
            $cliente = User::find($user->id)
                    ->clients()
                    ->where('id', '=', $client)
                    ->where('secret', '=', $secret)
                    ->first();
            if (isset($cliente->name) === false) {
                throw new Exception('No tiene acceso con este cliente.');
            }
            $aUser = Sentinel::authenticate($credentials);
            Log::info(Sentinel::getUser());
            return response()->json($aUser, 200);
        } catch (\Cartalyst\Sentinel\Checkpoints\NotActivatedException $e) {
            return response()->json(['error' => ['messages' => ['Usuario no activo']]], 500);
        } catch (\Exception $e) {
            return response()->json(['error' => ['messages' => [$e->getMessage()]]], 500);
        }
    }

    public function logout(Request $request) {
        Sentinel::logout();
    }

}
