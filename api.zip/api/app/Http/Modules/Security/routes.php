<?php

/*
  |--------------------------------------------------------------------------
  | Application Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register all of the routes for an application.
  | It's a breeze. Simply tell Laravel the URIs it should respond to
  | and give it the controller to call when that URI is requested.
  |
 */
Route::group(['middleware' => ['web','ACL']], function() {

    /**
     * Recurso de roles
     */
    Route::resource('roles', 'RolesController');
    Route::put('roles/restore/{id}', ['as' => 'security.roles.restore', 'uses' => 'RolesController@restore']);
    /**
     * Recurso de users
     */
    Route::resource('actions', 'ActionsController');
    Route::put('actions/restore/{id}', ['as' => 'security.actions.restore', 'uses' => 'ActionsController@restore']);
    /**
     * Recurso de users
     */
    Route::resource('modules', 'ModulesController');
    Route::put('modules/restore/{id}', ['as' => 'security.modules.restore', 'uses' => 'ModulesController@restore']);

    /**
     * Recurso de users
     */
    Route::resource('users', 'UsersController');
    Route::put('users/restore/{id}', ['as' => 'security.users.restore', 'uses' => 'UsersController@restore']);

    /**
     * Recurso de oauth_client
     */
    Route::resource('oauth_client', 'OauthClientsController');
    Route::get('oauth_client/{id}', ['as' => 'security.oauth_client.index', 'uses' => 'OauthClientsController@show']);
    Route::put('oauth_client/{id}', ['as' => 'security.oauth_client.update', 'uses' => 'OauthClientsController@update']);
    Route::delete('oauth_client/{id}', ['as' => 'security.oauth_client.destroy', 'uses' => 'OauthClientsController@destroy']);
    Route::put('oauth_client/restore/{id}', ['as' => 'security.oauth_client.restore', 'uses' => 'OauthClientsController@restore']);
});
