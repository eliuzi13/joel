<?php

/**
 * Controlador de recursos de Users
 */

namespace Pets\Http\Modules\Security\Controllers;

use Illuminate\Http\Request;
use Pets\Http\Base\Controller;
use Pets\Http\Modules\Security\Models\User;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use Cartalyst\Sentinel\Laravel\Facades\Activation;

class UsersController extends Controller {

    /**
     * Muestra una lista del recurso.
     *
     * @return Response
     */
    public function index(Request $request) {
        $paginate = $request->input('paginate', true);
        $attachable = $this->select($request, $paginate);
        if ($paginate == 0) {
            return response()->json(['data' => $attachable], 200);
        }
        return response()->json($attachable, 200);
    }

    /**
     * Filtra la lista del recurso.
     * @param Request $request
     * @param type $paginate
     * @return type
     */
    private function select(Request $request, $paginate = true) {
        $perPage = $request->input('perPage', 20);
        $orderby = $request->input('sort', 'created_at');
        $sentido = $request->input('order', 'asc');
        $likes = $request->only('first_name', 'last_name');
        $equal = $request->only('id', 'email');
        $withTrashed = $request->input('withTrashed', false);
        $query = User::like($likes)
                ->equal($equal)
                ->orderBy($orderby, $sentido);
        if ($withTrashed == '1') {
            $query->onlyTrashed();
        }
        if ($paginate == 0) {
            return $query->get();
        } else {
            return $query->paginate($perPage);
        }
    }

    /**
     * Guarda un nuevo recurso.
     *
     * @return Response
     */
    public function store(Request $request) {
       // $data = $request->only('first_name', 'last_name', 'email', 'password', 'permissions', 'clients');
        $data = $request->only('first_name', 'last_name', 'email', 'password', 'permissions', 'clients','roles');
        $user = Sentinel::create($data);
        $_user = User::find($user->id);
        $_user->roles()->sync($data['roles']);
        $_user->clients()->sync($data['clients']);
        $activation = Activation::create($user);
        Activation::complete($user, $activation->code);
        return $user;
    }

    /**
     * Mustra el recurso especificado.
     *
     * @param  int  $id
     * @return Response
     */
    public function show($id) {
        try {
            $user = Sentinel::findById($id);
            $_user = User::findOrFail($id);
            $user->password = null;
            $list = $user->roles()->lists('id');
            $user->roles = $list;
            $listC = $_user->clients()->lists('id');
            $user->clients = $listC;
            return response()->json($user, 200);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json(['error' => ['heading' => trans('messages.requestError')
                            , 'message' => trans('messages.notFound')]], 404);
        }
    }

    /**
     * Actualiza el recurso especificado.
     *
     * @param  int  $id
     * @return Response
     */
    public function update(Request $request, $id) {
        try {
            $data = $request->only('first_name', 'last_name', 'email', 'password', 'permissions', 'roles', 'clients');
            if (trim($data['password']) == '') {
                unset($data['password']);
            }
            $user = Sentinel::findById($id);
            $user = Sentinel::update($user, $data);
            $_user = User::find($user->id);
            $_user->roles()->sync($data['roles']);
            $_user->clients()->sync($data['clients']);
            return $user;
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json(['error' => ['heading' => trans('messages.requestError')
                            , 'message' => trans('messages.notFound')]], 404);
        }
    }

    /**
     * Remueve el recurso especificado.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy($id) {
        $user = Sentinel::findById($id);
        return response()->json($user->delete(), 200);
    }

    /**
     *  Restaura el recurso especificado.
     *
     * @param  int  $id
     * @return Response
     */
    public function restore($id) {
        try {
            return response()->json(User::withTrashed()->findOrFail($id)->restore(), 200);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json(['error' => ['heading' => trans('messages.requestError')
                            , 'message' => trans('messages.notFound')]], 404);
        }
    }

}
