<?php

/**
 * Controlador de recursos de Modules
 */

namespace Pets\Http\Modules\Security\Controllers;

use Illuminate\Http\Request;
use Pets\Http\Base\Controller;
use Pets\Http\Modules\Security\Models\Module;
use DB;

class ModulesController extends Controller {

    /**
     * Muestra una lista del recurso.
     *
     * @return Response
     */
    public function index(Request $request) {
        $paginate = $request->input('paginate', true);
        $modueles = $this->select($request, $paginate);
        if ($request->input('showActions', FALSE) === '1') {
            $arrModulesIds = [];
            foreach ($modueles as $module) {
                $arrModulesIds[] = $module->id;
            }
            $subActions = DB::table('actions AS act')
                            ->select('act.id', 'act.name', 'ma.module_id')
                            ->join('module_actions AS ma', 'act.id', '=', 'ma.action_id')
                            ->whereIn('ma.module_id', $arrModulesIds)->get();
            $collection = collect($subActions);
            $grouped = $collection->groupBy('module_id');
            $arrActions = $grouped->toArray();
            foreach ($modueles as $module) {
                $module->actions = $arrActions[$module->id];
            }
        }
        if ($paginate == 0) {
            return response()->json(['data' => $modueles], 200);
        }
        return response()->json($modueles, 200);
    }

    /**
     * Filtra la lista del recurso.
     * @param Request $request
     * @param type $paginate
     * @return type
     */
    private function select(Request $request, $paginate = true) {
        $perPage = $request->input('perPage', 20);
        $orderby = $request->input('sort', 'created_at');
        $sentido = $request->input('order', 'asc');
        $likes = $request->only('name');
        $equal = $request->only('id');
        $withTrashed = $request->input('withTrashed', false);
        $query = Module::like($likes)
                ->equal($equal)
                ->orderBy($orderby, $sentido);
        if ($withTrashed == '1') {
            $query->onlyTrashed();
        }
        if ($paginate == 0) {
            return $query->get();
        } else {
            return $query->paginate($perPage);
        }
    }

    /**
     * Guarda un nuevo recurso.
     *
     * @return Response
     */
    public function store(Request $request) {
        $data = $request->only('name', 'actions');
        $user = new Module();
        return $this->save($user, $data);
    }

    /**
     * Mustra el recurso especificado.
     *
     * @param  int  $id
     * @return Response
     */
    public function show($id) {
        try {
            $module = Module::findOrFail($id);
            $list = $module->actions()->lists('id');
            $module->actions = $list;
            return response()->json($module, 200);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json(['error' => ['heading' => trans('messages.requestError')
                            , 'message' => trans('messages.notFound')]], 404);
        }
    }

    /**
     * Actualiza el recurso especificado.
     *
     * @param  int  $id
     * @return Response
     */
    public function update(Request $request, $id) {
        try {
            $data = $request->only('name', 'actions');
            $module = Module::findOrFail($id);
            return $this->save($module, $data);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json(['error' => ['heading' => trans('messages.requestError')
                            , 'message' => trans('messages.notFound')]], 404);
        }
    }

    /**
     * Guarda o actualiza un recurso especificado
     * @return type
     */
    public function save(Module $module, $data) {
        $module->name = $data['name'];
        if (!$module->validate()) {
            return $module->responseError();
        }
        $module->save();
        $module->actions()->sync($data['actions']);
        return $module;
    }

    /**
     * Remueve el recurso especificado.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy($id) {
        return response()->json(Module::destroy($id), 200);
    }

    /**
     *  Restaura el recurso especificado.
     *
     * @param  int  $id
     * @return Response
     */
    public function restore($id) {
        try {
            return response()->json(Module::withTrashed()->findOrFail($id)->restore(), 200);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json(['error' => ['heading' => trans('messages.requestError')
                            , 'message' => trans('messages.notFound')]], 404);
        }
    }

}
