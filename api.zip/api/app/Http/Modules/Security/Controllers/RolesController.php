<?php

/**
 * Controlador de recursos de Roles
 */

namespace Pets\Http\Modules\Security\Controllers;

use Illuminate\Http\Request;
use Pets\Http\Base\Controller;
use Pets\Http\Modules\Security\Models\Role;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;

class RolesController extends Controller {

    /**
     * Muestra una lista del recurso.
     *
     * @return Response
     */
    public function index(Request $request) {
        $paginate = $request->input('paginate', true);
        $attachable = $this->select($request, $paginate);
        if ($paginate == 0) {
            return response()->json(['data' => $attachable], 200);
        }
        return response()->json($attachable, 200);
    }

    /**
     * Filtra la lista del recurso.
     * @param Request $request
     * @param type $paginate
     * @return type
     */
    private function select(Request $request, $paginate = true) {
        $perPage = $request->input('perPage', 20);
        $orderby = $request->input('sort', 'created_at');
        $sentido = $request->input('order', 'asc');
        $likes = $request->only('name');
        $equal = $request->only('id', 'email');
        $withTrashed = $request->input('withTrashed', false);
        $query = Role::like($likes)
                ->equal($equal)
                ->orderBy($orderby, $sentido);
        if ($withTrashed == '1') {
            $query->onlyTrashed();
        }
        if ($paginate == 0) {
            return $query->get();
        } else {
            return $query->paginate($perPage);
        }
    }

    /**
     * Guarda un nuevo recurso.
     *
     * @return Response
     */
    public function store(Request $request) {
        $data = $request->only('slug', 'name', 'permissions');
        $role = Sentinel::getRoleRepository()->createModel();
        return $this->save($role, $data);
    }

    /**
     * Mustra el recurso especificado.
     *
     * @param  int  $id
     * @return Response
     */
    public function show($id) {
        try {
            $role = Sentinel::findRoleById($id);
            return response()->json($role, 200);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json(['error' => ['heading' => trans('messages.requestError')
                            , 'message' => trans('messages.notFound')]], 404);
        }
    }

    /**
     * Actualiza el recurso especificado.
     *
     * @param  int  $id
     * @return Response
     */
    public function update(Request $request, $id) {
        try {
            $data = $request->only('slug', 'name', 'permissions');
            $role = Sentinel::findRoleById($id);
            return $this->save($role, $data);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json(['error' => ['heading' => trans('messages.requestError')
                            , 'message' => trans('messages.notFound')]], 404);
        }
    }

    /**
     * Guarda o actualiza un recurso especificado
     * @return type
     */
    public function save($role, $data) {
        $role->slug = $data['slug'];
        $role->name = $data['name'];
        $role->permissions = $data['permissions'];
        $role->save();
        return $role;
    }

    /**
     * Remueve el recurso especificado.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy($id) {
        return response()->json(Role::destroy($id), 200);
    }

    /**
     *  Restaura el recurso especificado.
     *
     * @param  int  $id
     * @return Response
     */
    public function restore($id) {
        try {
            return response()->json(Role::withTrashed()->findOrFail($id)->restore(), 200);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json(['error' => ['heading' => trans('messages.requestError')
                            , 'message' => trans('messages.notFound')]], 404);
        }
    }

}
