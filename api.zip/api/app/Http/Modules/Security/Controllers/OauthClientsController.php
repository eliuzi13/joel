<?php

/**
 * Controlador de recursos de OauthClients
 */

namespace Pets\Http\Modules\Security\Controllers;

use Illuminate\Http\Request;
use Pets\Http\Base\Controller;
use Pets\Http\Modules\Security\Models\OauthClient;
use DB;

class OauthClientsController extends Controller {

    /**
     * Muestra una lista del recurso.
     *
     * @return Response
     */
    public function index(Request $request) {
        $paginate = $request->input('paginate', true);
        $client = $this->select($request, $paginate);
        if ($paginate == 0) {
            return response()->json(['data' => $client], 200);
        }
        return response()->json($client, 200);
    }

    /**
     * Filtra la lista del recurso.
     * @param Request $request
     * @param type $paginate
     * @return type
     */
    private function select(Request $request, $paginate = true) {
        $perPage = $request->input('perPage', 20);
        $orderby = $request->input('sort', 'created_at');
        $sentido = $request->input('order', 'asc');
        $likes = $request->only('name');
        $equal = $request->only('id', 'secret');
        $withTrashed = $request->input('withTrashed', false);
        $query = OauthClient::like($likes)
                ->equal($equal)
                ->orderBy($orderby, $sentido);
        if ($withTrashed == '1') {
            $query->onlyTrashed();
        }
        if ($paginate == 0) {
            return $query->get();
        } else {
            return $query->paginate($perPage);
        }
    }

    /**
     * Guarda un nuevo recurso.
     *
     * @return Response
     */
    public function store(Request $request) {
        $data = $request->only('name', 'secret', 'id');
        $client = new OauthClient();
        return $this->save($client, $data);
    }

    /**
     * Mustra el recurso especificado.
     *
     * @param  int  $id
     * @return Response
     */
    public function show($id) {
        try {
            $client = OauthClient::findOrFail($id);
            return response()->json($client, 200);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json(['error' => ['heading' => trans('messages.requestError')
                            , 'message' => trans('messages.notFound')]], 404);
        }
    }

    /**
     * Actualiza el recurso especificado.
     *
     * @param  int  $id
     * @return Response
     */
    public function update(Request $request, $id) {
        try {
            $data = $request->only('name', 'secret');
            $client = OauthClient::findOrFail($id);
            $data['id'] = $id;
            return $this->save($client, $data);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json(['error' => ['heading' => trans('messages.requestError')
                            , 'message' => trans('messages.notFound')]], 404);
        }
    }

    /**
     * Guarda o actualiza un recurso especificado
     * @return type
     */
    public function save(OauthClient $client, $data) {
        $client->id = $data['id'];
        $client->name = $data['name'];
        $client->secret = $data['secret'];
        if (!$client->validate()) {
            return $client->responseError();
        }
        $client->save();
        return $client;
    }

    /**
     * Remueve el recurso especificado.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy($id) {
        return response()->json(OauthClient::destroy($id), 200);
    }

    /**
     *  Restaura el recurso especificado.
     *
     * @param  int  $id
     * @return Response
     */
    public function restore($id) {
        try {
            return response()->json(OauthClient::withTrashed()->findOrFail($id)->restore(), 200);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json(['error' => ['heading' => trans('messages.requestError')
                            , 'message' => trans('messages.notFound')]], 404);
        }
    }

}
