<?php

namespace Pets\Http\Modules\Security\Models;


use Pets\Http\Base\SoftDeletes;
use Pets\Http\Base\ExtendModel;
use Cartalyst\Sentinel\Users\EloquentUser as CartalystUser;

class User extends CartalystUser
{
    use SoftDeletes,ExtendModel;

  /**
     * Relacion con grupos 
     * @return type
     */
    public function roles() {
        return $this->belongsToMany('Pets\Http\Modules\Security\Models\Role', 'role_users', 'user_id', 'role_id');
    }
    
    
    public function clients() {
        return $this->belongsToMany('Pets\Http\Modules\Security\Models\OauthClient', 'users_clients', 'user_id', 'client_id');
    }
      
}
