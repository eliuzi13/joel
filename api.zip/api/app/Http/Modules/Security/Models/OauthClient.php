<?php

namespace Pets\Http\Modules\Security\Models;

use Pets\Http\Base\ExtendModel;
use Illuminate\Database\Eloquent\Model;
use Pets\Http\Base\SoftDeletes;

class OauthClient extends Model {
    use SoftDeletes,ExtendModel;
  /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'oauth_clients';
    /**
     * Llave primaria de la tabla
     * @var type 
     */
    public $primaryKey = 'id';
     /**
     * Atributos sin asignacion masiva
     * @var type 
     */
    protected $guarded = [];

    /**
     * Reglas de validacion
     * @var type 
     */
    protected static $rules = [
        "name"=>"required",
        "secret"=>"required"
    ];
        /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [];
      /**
     * Indicates if the model should be timestamped.
     *
     * @var bool
     */
    public $timestamps = true;
     /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = ['created_at', 'updated_at'];
}
