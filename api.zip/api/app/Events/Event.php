<?php

namespace Pets\Events;

abstract class Event
{
    //
}
