<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersClientsTable extends Migration {

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up() {
        Schema::create('users_clients', function (Blueprint $table) {
            $table->string('client_id');
            $table->integer('user_id')->unsigned();
            $table->foreign('client_id')->references('id')->on('oauth_clients');
            $table->foreign('user_id')->references('id')->on('users');
            $table->primary(['client_id', 'user_id']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down() {
        Schema::drop('users_clients');
    }

}
