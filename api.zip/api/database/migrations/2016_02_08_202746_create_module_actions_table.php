<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateModuleActionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('module_actions', function (Blueprint $table) {
            $table->integer('module_id')->unsigned();
            $table->integer('action_id')->unsigned();
            $table->foreign('module_id')->references('id')->on('modules');
            $table->foreign('action_id')->references('id')->on('actions');
            $table->primary(['action_id', 'module_id']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('module_actions');
    }
}
