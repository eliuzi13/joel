<?php

return [
    'clientDenied' => 'No tiene acceso a este cliente',
    'actionDenied'=>'No tiene permisos para ejectuar esta acción',
    'notFound'=>'No encontrado',
    'incorrectPassword'=>'Contraseña incorrecta',
    'incorrectUser'=>'Usuario incorrecto',
    'inactiveUser'=>'Usuario unacativo',
    'susependedUser'=>'Usuario suspendido',
    'banedUser'=>'Usuario bloqueado',
    'userNotLoged'=>'Usuario no esta logeado',
    'requestError'=>'Error de petición'

];
