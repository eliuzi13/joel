<?php

return [
    'error' => 'Error',
    'secret' => 'Secret',
    'client' => 'Cliente',
    'clients' => 'Clientes',
    'email' => 'Email',
    'password' => 'Contraseña',
    'user' => 'Usuario',
    'users' => 'Usuarios',
    'group' => 'Grupo',
    'groups' => 'Grupos',
    'module' => 'Modulo',
    'modules' => 'Modulos',
    'action' => 'Acción',
    'actions' => 'Acciones',
    'name' => 'Nombre',
    'description' => 'Descripción',
    'reportOf'=>'Reporte de',
    'firstName'=>'Nombre(s)',
    'lastName'=>'Apellido(s)',
    'login'=>'Inicio de sesión',
    'ok'=>'OK',
    'filed'=>'Fallo'
];
