# grunt-angular-templates Contributors

*Source: [Contributor Graph][1]*


- [Eric Clemmons](https://github.com/ericclemmons/grunt-angular-templates/commits?author=@ericclemmons)
- [Chris Gross](https://github.com/ericclemmons/grunt-angular-templates/commits?author=@cgross)
- [Mario J. Barchéin Molina](https://github.com/ericclemmons/grunt-angular-templates/commits?author=@mbarchein)
- [Robert Klep](https://github.com/ericclemmons/grunt-angular-templates/commits?author=@robertklep)
- [Kai Groner](https://github.com/ericclemmons/grunt-angular-templates/commits?author=@groner)
- [DallonF](https://github.com/ericclemmons/grunt-angular-templates/commits?author=@dallonf)
- [Mike Brevoort](https://github.com/ericclemmons/grunt-angular-templates/commits?author=@mbrevoort)
- [Sid Wood](https://github.com/ericclemmons/grunt-angular-templates/commits?author=@sidwood)
- [Tadeusz Wójcik](https://github.com/ericclemmons/grunt-angular-templates/commits?author=@codefather)
- [Joe Grund](https://github.com/ericclemmons/grunt-angular-templates/commits?author=@jgrund)


[1]: https://github.com/ericclemmons/grunt-angular-templates/contributors
