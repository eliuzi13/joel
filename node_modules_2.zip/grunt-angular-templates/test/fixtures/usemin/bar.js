/**
 * bar.js
 */

var Bar = 'bar';
