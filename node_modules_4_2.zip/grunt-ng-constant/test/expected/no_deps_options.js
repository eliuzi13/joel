angular.module('module1')

.constant('constant1', {global_key:'global_value'})

;;