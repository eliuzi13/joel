angular.module('stringConstantsOptionsModule', [])

.constant('constant1', {global_key:'global_value',key1:'value1',key2:'value2'})

;;