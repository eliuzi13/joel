/*jshint -W109*/
define(function (require) {
    'use strict';

    var angular = require('angular');

    angular.module("templateOptionsModule", [])
    .constant("constant1", 'value1');

});