angular.module('module1', [])

.constant('constant1', {global_key:'overriden_global_value'})

;;