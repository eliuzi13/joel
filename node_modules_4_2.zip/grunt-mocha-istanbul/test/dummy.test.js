var task = require('../tasks/index');

describe('grunt mocha istanbul', function(){
  it('should pass', function(){
  });
});