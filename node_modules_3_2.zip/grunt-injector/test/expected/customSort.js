
var files = [
/** tagstart */
  {ext: 'html', file: '/component.html'},
  {ext: 'js', file: '/script.js'},
  {ext: 'css', file: '/style.css'},
/** tagend */
];
