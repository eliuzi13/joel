
var files = [
/** tagstart */
  {ext: 'js', file: '/script.js'},
  {ext: 'css', file: '/style.css'},
  {ext: 'html', file: '/component.html'},
/** tagend */
];
