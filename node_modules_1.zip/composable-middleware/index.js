
/*
 * composable-middleware
 * https://github.com/randymized/composable-middleware
 *
 * Copyright (c) 2013 Randy McLaughlin
 * Licensed under the MIT license.
 */

'use strict';

var composable_middleware = require( './lib/composable-middleware.js' );

module.exports = composable_middleware;
