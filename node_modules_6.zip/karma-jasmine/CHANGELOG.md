<a name="0.3.8"></a>
## [0.3.8](https://github.com/karma-runner/karma-jasmine/compare/v0.3.7...v0.3.8) (2016-03-16)


### Bug Fixes

* v0.3.7 does not work in ie8 fix #105 ([d44b489](https://github.com/karma-runner/karma-jasmine/commit/d44b489)), closes [#105](https://github.com/karma-runner/karma-jasmine/issues/105)

### Features

* **adapter:** add executedExpectationsCount to result ([666c207](https://github.com/karma-runner/karma-jasmine/commit/666c207))



