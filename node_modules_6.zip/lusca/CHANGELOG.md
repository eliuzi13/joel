##### v1.3.0

* Add `req.csrfToken` method to (re)generate token

##### v1.2.0

* Add angular convenience wrapper around CSRF cookie configuration

##### v1.1.1

* Fix csrf header case-sensitivity

##### v1.1.0

* Add `preload` flag to HSTS options

##### v0.1.2 - 20131231

* Add support for HTTP Strict Transport (HSTS) header

##### v0.1.1 - 2013xxxx
**Bugs**
-

**Features**
-
