<a name"0.2.3"></a>
### 0.2.3 (2016-01-04)


#### Bug Fixes

* Correct cli argument order ([e33946dc](https://github.com/karma-runner/karma-phantomjs-launcher/commit/e33946dc), closes [#92](https://github.com/karma-runner/karma-phantomjs-launcher/issues/92), [#94](https://github.com/karma-runner/karma-phantomjs-launcher/issues/94))


<a name"0.2.2"></a>
### 0.2.2 (2015-12-24)


#### Bug Fixes

* pass PhantomJS script as the first cmd-line argument ([1c195c6b](https://github.com/karma-runner/karma-phantomjs-launcher/commit/1c195c6b))
* do not duplicate cmd-line flags on repeated PhantomJS runs ([76228f18](https://github.com/karma-runner/karma-phantomjs-launcher/commit/76228f18))


<a name"0.2.1"></a>
### 0.2.1 (2015-08-05)


#### Bug Fixes

* ensure console output from phantomjs is available in karma debug logs ([eed281b5](https://github.com/karma-runner/karma-phantomjs-launcher/commit/eed281b5))

<a name"0.2.0"></a>
## 0.2.0 (2015-05-29)


#### Bug Fixes

* **npm:** Make .npmignore more sensible to dot files ([1322a89d](https://github.com/karma-runner/karma-phantomjs-launcher/commit/1322a89d), closes [#68](https://github.com/karma-runner/karma-phantomjs-launcher/issues/68))


#### Features

* Move phantomjs to peerDeps, #37, #42, #56 ([a0f399de](https://github.com/karma-runner/karma-phantomjs-launcher/commit/a0f399de), closes [#25](https://github.com/karma-runner/karma-phantomjs-launcher/issues/25))
* Support option for phantom to exit on ResourceError ([2b90c6b9](https://github.com/karma-runner/karma-phantomjs-launcher/commit/2b90c6b9))
* debug option ([c6dfe786](https://github.com/karma-runner/karma-phantomjs-launcher/commit/c6dfe786))
